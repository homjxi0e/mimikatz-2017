#!/bin/bash

clear
#DEFINED COLOR SETTINGS
RED=$(tput setaf 1 && tput bold)
GREEN=$(tput setaf 2 && tput bold)
STAND=$(tput sgr0)
BLUE=$(tput setaf 6 && tput bold)



echo ""
echo ""
echo ""
echo $RED"              +##############################################+"
echo $RED"              +     ﺓﺍﺩﻻ​ﺍ ﻲﻟ ﻡﺪﺤﺘﺴﻣ ﻞﻜﻟ ﺃﺮﻜﺷ                 +"
echo $RED"              +                                              +"
echo $RED"              +              ﻲﺑﺎﺴﺣ ﻰﻠﻋ ﻞﺻﺍﻮﺘﻟ                +"
echo $RED"              +                                              +"
echo $RED"              + https://www.facebook.com/Gihad.Metasploit    +"
echo $RED"              +##############################################+"
echo ""
echo $BLUE"     (ﻙﻮﺒﺴﻴﻓ ﻰﻠﻋ ﻲﺑﺎﺴﺣ) http://www.facebook.com.com/Gihad.Metasploit."
echo ""
echo $BLUE"   ( ﺏﻮﻴﺗﻮﻳ ﻰﻠﻋ ﻲﺗﺎﻨﻗ) https://www.youtube.com/channel/UCubdeDNFXMJDOyM9Xa6xRfg."
sleep 10
clear

echo ""
echo $RED"                   **************************************";
echo $RED"                   *    11 11 ﻢﻗﺭ ﻂﺣ ﺖﻳﻮﻠﺒﺳﺎﻴﺘﻤﻟ​ﺍ ﺢﺘﻔﻟ  *";
echo $RED"                   *    1ﻂﺣ ﻥﻮﻴﻠﻤﻟ​ﺍ ﺖﺒﺣﺎﺻ ﺔﺘﺴﻟ ﻦﻳﻮﻜﺗ ﻲﻟ *";
echo $RED"                   *    2.  2 ﻢﻗﺭ ﻂﺣ ﻊﻗﺍﻮﻤﻟ​ﺍ ﺺﺤﻓ ﻲﻟ     *";
echo $RED"                   *    4.  4ﻂﻐﺿﺍ dnsenum ﻲﺑ ﻊﻗﺍﻮﻣ ﺺﺤﻔﻟ *";
echo $RED"                   *    6. 6ﻂﻐﺿﺍ Nmap ﺓﺩﺎﺑ ﺓﺰﻬﺟﻻ​ﺍ ﺺﺤﻓ ﻲﻟ*";  
echo $RED"                   *    8.  EXIT                        *"; 
echo $RED"                   **************************************";

echo $BLUE"                             ﻲﻃﺎﻤﻘﻟ​ﺍ ﺩﺎﻬﺟ  ﺓﺍﺩﺍ ﻲﻓ ﻚﺑ ﺎﺒﺣﺮﻣ "$STAND
read menuoption


if [ $menuoption = "1" ]; then
echo "ﺮﺳ ﺕﺎﻤﻠﻛ ﺎﻬﻴﻠﻋ ﻲﺒﺗ ﻲﻟ​ﺍ ﺀﺎﻤﺳﻻ​ﺍ ﻂﺣ ﺎﻨﻫ"
read target
crunch 1 100 $target
echo ""
read -p "ﺝﻭﺮﺨﻠﻟ ﺮﺘﻧﺍ ﻂﻐﺿﺍ"
./Gihad.sh
else

if [ $menuoption = "2" ]; then
echo "ﺔﺼﺤﻓ ﺩﺍﺮﻤﻟ​ﺍ ﻊﻗﻮﻤﻟ​ﺍ ﻂﺣ"
read target
dig $target any
echo ""
echo ""
host -l $target
echo ""
read -p "ﺝﻭﺮﺨﻠﻟ ﺮﺘﻧﺍ ﻂﻐﺿﺍ"
./Gihad.sh
else


if [ $menuoption = "5" ]; then
echo "ﺔﺼﺤﻓ ﺩﺍﺮﻤﻟ​ﺍ ﺯﺎﻬﺠﻟ​ﺍ ﻲﺑ ﻱﺍ ﻂﺣ ﺎﻨﻫ"
read target
echo ""
cd /usr/bin
fierce -dns $target
echo ""
read -p "ﺝﻭﺮﺨﻠﻟ ﺮﺘﻧﺍ ﻂﻐﺿﺍ"
./Gihad.sh
else

if [ $menuoption = "4" ]; then
echo "ﺔﺼﺤﻓ ﺩﺍﺮﻤﻟ​ﺍ ﻊﻗﻮﻤﻟ​ﺍ ﻂﺣ"
read target
echo ""
cd /usr/bin
dnsenum --enum -f /usr/share/dnsenum/dns.txt --update a -r $target
echo ""
read -p "ﺝﻭﺮﺨﻠﻟ ﺮﺘﻧﺍ ﻂﻐﺿﺍ"
./GIhad.sh
else

if [ $menuoption = "11" ]; then
echo "ﺮﺘﻧﺍ ﻂﻐﺿﺍ"
read target
echo ""
cd /root
msfconsole
echo ""

if [ $menuoption = "6" ]; then
echo "ﺔﺼﺤﻔﺗ ﻲﺒﺗ ﻲﻟ​ﺍ ﺯﺎﻬﺠﻟ​ﺍ ﻲﺑ ﻱﺍ ﻂﺣ ﺎﻨﻫ"
read target
echo ""
cd /root
nmap -v $target.txt $target
echo ""
read -p "ﺝﻭﺮﺨﻠﻟ ﺮﺘﻧﺍ ﻂﻐﺿﺍ"
exit

if [ $menuoption = "11" ]; then
echo "ﺮﺘﻧﺍ ﻂﻐﺿﺍ"
read target
echo ""
cd /root
msfconsole
echo ""

if [ $menuoption = "8" ]; then
exit
fi
fi
fi
fi
fi
fi
fi
fi















